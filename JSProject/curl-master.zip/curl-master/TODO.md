# TODO

## before 0.7.4 release

* investigate all variations of data-curl-run
	* split path from file name. path = baseUrl, file = main
	* if comma-sep (data-curl-run="js/bundle,js/run"),
	  main = "run", not "bundle" ???
* document data-curl-run and link from [Configuring curl.js]
* Investigate IE intermittent silent failure issues

## possibly before 0.7.4 release

* move docs from wiki to docs folder
