testDomain.awesome = {};
testDomain.awesome.sauce = 'ketchup';
