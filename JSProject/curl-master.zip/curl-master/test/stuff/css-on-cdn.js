define(["css!dijit/claro/claro.css","css!dojo/dojo.css"], function (ss1, ss2) {
	return 1;
});
