define(function () {
	// returns nothing
});