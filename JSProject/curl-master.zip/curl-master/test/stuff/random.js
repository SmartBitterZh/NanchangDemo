window.random = Math.random();
