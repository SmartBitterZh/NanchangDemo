/*
 * depends on 'test1'
 */
define(['test1'], function (test1) {
	return test1;
});
