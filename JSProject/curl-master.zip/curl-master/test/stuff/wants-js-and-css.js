define(["js!stuff/plain_old.js", "css!stuff/base.css"], function (plain, ss) {
	return "47%";
});
