/*
 * depends on 'test1'
 */
define(function (require) {
	return require('test1');
});
