foo.bar([], function () {

	return 1;

});
