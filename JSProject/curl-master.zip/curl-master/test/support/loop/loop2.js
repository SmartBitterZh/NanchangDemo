define(['./loop3'], function (loop3) {
	return loop3;
});
