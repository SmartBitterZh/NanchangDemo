define(['./loop1'], function (loop1) {
	return 'this is from loop3';
});
