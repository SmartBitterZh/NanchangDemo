define(['./loop1'], function (loop1) {
	return loop1;
});