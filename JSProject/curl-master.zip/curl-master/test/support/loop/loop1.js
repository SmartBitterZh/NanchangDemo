define(['./loop2'], function (loop2) {
	return loop2;
});
