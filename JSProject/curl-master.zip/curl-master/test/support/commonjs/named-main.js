define('named/named-main', function (require, exports) {

	exports.name = 'named';

});
