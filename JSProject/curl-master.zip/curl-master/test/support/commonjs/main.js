define(function (require, exports, module) {
	exports.id = module.id;
});
