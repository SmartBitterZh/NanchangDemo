// simple module with require()
var simple = require('./nakedSimpleCjsm1.1');
exports.testMessage = simple.testMessage;
exports.stuff = 'stuff';
