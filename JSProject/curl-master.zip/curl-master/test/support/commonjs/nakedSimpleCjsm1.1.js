// simple module without require()
exports.testMessage = 'test';
exports.uri = module.uri;
exports.id = module.id;
