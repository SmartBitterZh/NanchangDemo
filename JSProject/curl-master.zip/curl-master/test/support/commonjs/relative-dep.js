define(function () {
	return 'dep';
});
