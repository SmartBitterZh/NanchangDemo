define(function (require, exports, module) {
	exports.id = 'foo';
});
