define({
	itWorks: 'it works'
});
