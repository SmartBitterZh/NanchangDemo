define(['./relative-dep'], function (dep) {
	return dep;
});
