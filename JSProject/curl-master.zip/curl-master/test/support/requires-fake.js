define(['./fake!foo'], function (foo) {

	return {};

});
