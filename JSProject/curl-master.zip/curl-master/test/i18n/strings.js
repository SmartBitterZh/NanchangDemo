define({

	labels: {
		beer: 'brew',
		abode: 'apartment',
		transport: 'bus'
	},

	values: {
		date: '01/01/2010',
		number: 5,
		boolean: true,
		string: 'string'
	}

});